const InsideSkull = () => {

    const style = {
        inside: "text-[100px]"
    }

    return(
        <div className={style.inside}>Hello Skull</div>
    )
}

export default InsideSkull;